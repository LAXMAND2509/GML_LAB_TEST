#include<GL/glut.h>
#include<iostream>
#include<math.h>
#define PI 3.14159
using namespace std;

/***UTILITY FUNCTIONS***/


/***QUESTION FUNCTIONS***/

/***DISPLAY FUNCTIONS***/
void display(){
	glClearColor(1, 1, 1, 1);
     	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     	glMatrixMode(GL_MODELVIEW);
     	glPushMatrix();
     	
     	int choice=1;
     	switch(choice){
         	//Parallel Projection
         	case 1: glOrtho(-2, 2, -2, 2, -2, 2); break;
        	//Perspective Projection
        	case 2: gluPerspective(120, 1, 0.1, 50); break;
        	//FoVy = 120, Aspect Ratio = 1
     	}
     	gluLookAt(0, 0, 1, 0, 0, 0, 0, 1, 0); 
    	glRotatef(60, 1, 0, 0);         //Keyboard based rotations
     	glRotatef(60, 0, 1, 0);
     	glColor4f(0, 0, 1, 0.3); //Draw the object
     	glutWireTeapot(0.5);
     	glPopMatrix();
	glFlush();
} 
int main(int argc, char* argv[]){
    glutInit(&argc, argv); //Mandatory. Initializes the GLUT library. 
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1380, 700); //Set the size of output window (kinda optional)
    glutInitWindowPosition(200, 200); //position of output window on screen (optional)    
    glutCreateWindow("3D TRANSFORMATIONS");// Giving name to window
    glClearColor(1.0, 1.0, 1.0, 1.0); //Clear the buffer values for color AND set these values
    /*can set initial color here also*/
    glMatrixMode(GL_PROJECTION);  //Uses something called "projection matrix" to represent
    glLoadIdentity(); //load the above matrix to fill with identity values
    glutDisplayFunc(display); //sets the display callback for the current window
    glutMainLoop(); //Enters event processing loop. Compulsory
   return 0;
}
