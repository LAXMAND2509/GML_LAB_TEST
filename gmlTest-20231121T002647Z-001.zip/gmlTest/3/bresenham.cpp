#include<GL/glut.h>
#include<iostream>
#include<math.h>
using namespace std;

void point(int x,int y){
	glBegin(GL_POINTS);
	glVertex2f(x,y);
	glEnd();
}

void bres(int x0, int y0, int x1, int y1){
	float x=x0, y=y0;
	float dx=x1-x0;
	float dy=y1-y0;
	
	int ix = dx/abs(dx);
	int iy = dy/abs(dy);
	
	point(x,y);
	
	int p = 2*dy - dx;
	
	if(abs(dx)>abs(dy))
	while(x<x1 || y<y1){
		if(p<0){p = p + 2*dy; x+=ix;}
		else{p = p + 2*dy - 2*dx; x+=ix; y+=ix;}
		point(x,y);
	}
	else
	while(x<x1 || y<y1){
		if(p<0){p = p + 2*dx; y+=iy;}
		else{p = p + 2*dx - 2*dy; x+=ix; y+=ix;}
		point(x,y);
	}
	
}

void disp(){
	glClearColor(0,0,0,1);
	glColor3f(0,1,0);
	bres(0,0,75,100);
	bres(0,0,100,75);
	bres(0,0,87.5,87.5);

	glFlush();
}

int main(int ac, char* av[]){
	glutInit(&ac,av);
	glutInitWindowSize(500,500);
	glutInitWindowPosition(0,0);
	glutCreateWindow("WINDOW");
	//---------------------------------
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-250,250,-250,250);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}
