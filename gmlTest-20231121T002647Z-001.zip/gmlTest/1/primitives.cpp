//Bresenham practice for Test
#include<stdio.h>
#include<GL/glut.h> //Change to <GLUT/glut.h> in Mac
#include<math.h>
#include<string.h>

/* This is just to call the functions 
 also draw X and Y axis here and use output to label stuff) */
void display (void){
   
    
    //White
    glColor3f(1.0, 1.0, 1.0); 
    
    /*---Y Axis---*/
    glBegin(GL_LINES); //Begin followed by...
    glVertex2d(0, 420);
    glVertex2d(0, -420); 
    glEnd(); //...End
    
    /*---X Axis---*/
    glBegin(GL_LINES);
    glVertex2d(780, 0);
    glVertex2d(-780, 0);
    glEnd();
       

    //Call function
    glBegin(GL_POINTS);
    glColor3f(0.0, 1.0, 0.0); //Green
    glVertex2d(150,100);
    glEnd();
    
    glBegin(GL_LINES);
    glVertex2d(150,150);
    glVertex2d(150,200);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(0.0f, 1.0f, 0.0f); //green
    glVertex2d(300, 300);
    glVertex2d(300, 350);
    glVertex2d(350, 350);
    glVertex2d(350, 300);
    glVertex2d(300, 300);
    glEnd();
    
    glBegin(GL_TRIANGLES);          // Each set of 3 vertices form a triangle
    glColor3f(0.0f, 0.0f, 1.0f); //blue
    glVertex2d(-350, -350);
    glVertex2d(-400, -350);
    glVertex2d(-400, -300);
    glVertex2d(-350, -350);
    glEnd();
    
    glBegin(GL_POLYGON);            // These vertices form a closed polygon
    glColor3f(1.0f, 1.0f, 0.0f); // Yellow
    glVertex2d(200, 200);
    glVertex2d(200, 220);
    glVertex2d(220, 240);
    glVertex2d(240, 200);
    glVertex2d(230, 250);
    glVertex2d(250, 250);
    glVertex2d(200, 200);
    glEnd();
   

   
    glFlush();
}

int main (int argc, char** argv){
    /*--------WINDOW INITS-------*/
    glutInit(&argc, argv); //Mandatory. Initializes the GLUT library. 
    glutInitWindowSize(1380, 700); //Set the size of output window (kinda optional)
    glutInitWindowPosition(200, 200); //position of output window on screen (optional)    
    glutCreateWindow("TEMPLATE"); // Giving name to window

    /*-------OTHER INITS-------*/
    glClearColor(0.0, 0.0, 0.0, 1.0); //Clear the buffer values for color AND set these values
    /*can set initial color here also*/
    glMatrixMode(GL_PROJECTION);  //Uses something called "projection matrix" to represent
    glLoadIdentity(); //load the above matrix to fill with identity values
    gluOrtho2D(-780, 780, -420, 420); //define 2d viewing region (with L,R,B,T clipping coors)
    glutDisplayFunc(display); //sets the display callback for the current window
    glutMainLoop(); //Enters event processing loop. Compulsory
}
