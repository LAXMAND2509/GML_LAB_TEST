#include<GL/glut.h>
#include<iostream>
#include<math.h>
using namespace std;

void point(float x,float y){
	glBegin(GL_POINTS);
	glVertex2f(x,y);
	glEnd();
}

void circle(float x0, float y0, float r){
	float x=0,y=r, p=1-r;
	
	while(x<=y){
		point(x+x0,y+y0);
		point(-x+x0,y+y0);
		point(-x+x0,-y+y0);
		point(x+x0,-y+y0);
		point(y+x0,x+y0);
		point(-y+x0,x+y0);
		point(-y+x0,-x+y0);
		point(y+x0,-x+y0);
		
		if(p<0){ p = p + 1 + 2*x; x++;}
		else{ p = p + 1 + 2*x - 2*y; x++; y--;}
	}
}

void disp(){
	glClearColor(0,0,0,1);
	glColor3f(0,1,0);
	
	circle(0,0,40);
	circle(0,0,80);
	circle(0,0,120);
	circle(80,0,40);
	circle(-80,0,40);
	circle(0,80,40);
	circle(0,-80,40);
	circle(80/1.414,80/1.414,40);
	circle(-80/1.414,80/1.414,40);
	circle(-80/1.414,-80/1.414,40);
	circle(80/1.414,-80/1.414,40);
	glFlush();
}

int main(int ac, char* av[]){
	glutInit(&ac,av);
	glutInitWindowSize(500,500);
	glutInitWindowPosition(0,0);
	glutCreateWindow("WINDOW");
	//---------------------------------
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-250,250,-250,250);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}
