#include<GL/glut.h>
#include<iostream>
#include<math.h>
#define PI 3.14159
using namespace std;

/***UTILITY FUNCTIONS***/
//point and matrix info
double v1[]={10,10,10, 1}, v2[]={10,60,10,1}, v3[]={60,60,10,1}, v4[]={60,10,10,1}, v5[]={10,10,60,1}, v6[]={10,60,60,1}, v7[]={60,60,60,1}, v8[]={60,10,60,1};
double mat[4][4];
//identity function
void identity(){
	mat[0][0] = 1; mat[0][1] = 0; mat[0][2] = 0; mat[0][3] = 0;
	mat[1][0] = 0; mat[1][1] = 1; mat[1][2] = 0; mat[1][3] = 0;
	mat[2][0] = 0; mat[2][1] = 0; mat[2][2] = 1; mat[2][3] = 0;
	mat[3][0] = 0; mat[3][1] = 0; mat[3][2] = 0; mat[3][3] = 1;
}

void solid(double v1[], double v2[], double v3[], double v4[], double v5[], double v6[], double v7[], double v8[]){
	glBegin(GL_QUADS);
	glColor3f(1,0,0);
	glVertex3dv(v1); glVertex3dv(v2); glVertex3dv(v3); glVertex3dv(v4);
	
	glColor3f(0,1,0);
	glVertex3dv(v2); glVertex3dv(v3); glVertex3dv(v7); glVertex3dv(v6);
	
	glColor3f(0,1,1);
	glVertex3dv(v5); glVertex3dv(v6); glVertex3dv(v7); glVertex3dv(v8);
	
	glColor3f(1,1,0);
	glVertex3dv(v5); glVertex3dv(v8); glVertex3dv(v4); glVertex3dv(v1);
	
	glColor3f(1,0,1);
	glVertex3dv(v1); glVertex3dv(v2); glVertex3dv(v6); glVertex3dv(v5);
	
	glColor3f(0,0,1);
	glVertex3dv(v3); glVertex3dv(v4); glVertex3dv(v8); glVertex3dv(v7);
	glEnd();
	
	glFlush();
}
//multiply function
void mm(double m[4][4], double v[4]){
    double res[4];
    for(int i = 0; i < 4; ++i){
        double temp=0;
        for(int k = 0; k < 4; ++k)
            temp += m[i][k] * v[k];
        res[i]=temp;
    }
    for(int i = 0; i < 4; ++i)
        v[i] = res[i];
}

/***QUESTION FUNCTIONS***/
void translate(double tx, double ty, double tz){mat[0][3] = tx; mat[1][3] = ty; mat[2][3] = tz;}
void scale(int sx, int sy, int sz) { mat[0][0] = sx; mat[1][1] = sy; mat[2][2] = sz;}

/***DISPLAY FUNCTIONS***/
void display(){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    //axes
  glColor3f(0.0, 0.0, 0.0); 
  glBegin(GL_LINES); // Plotting X-Axis
  glVertex3d(-1000, 0, 0);
  glVertex3d(1000, 0, 0);
  glEnd();
  glBegin(GL_LINES); // Plotting Y-Axis
  glVertex3d(0, -1000, 0);
  glVertex3d(0, 1000, 0);
  glEnd();
  glBegin(GL_LINES); // Plotting Z-Axis
  glVertex3d(0, 0, -1000);
  glVertex3d(0, 0, 1000);
  glEnd();
  
  //original
 
   solid(v1,v2,v3,v4,v5,v6,v7,v8);
   
   //TRANSFORMATION
	int choice = 2;
	switch(choice){
		case 1: translate(100,100,100); break;
		case 2: scale(-2,2,2); break;
		/**OTHERS AS USUAL**/
		
		default: cout<<"error"; break;
	}
	mm(mat,v1); mm(mat,v2); mm(mat,v3); mm(mat,v4); mm(mat,v5); mm(mat,v6); mm(mat,v7); mm(mat,v8);
	
	//TRANSFORMED OBJECT
	
	 solid(v1,v2,v3,v4,v5,v6,v7,v8);
  glFlush();
} 
int main(int argc, char* argv[]){
    glutInit(&argc, argv); //Mandatory. Initializes the GLUT library. 
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1380, 700); //Set the size of output window (kinda optional)
    glutInitWindowPosition(200, 200); //position of output window on screen (optional)    
    glutCreateWindow("3D TRANSFORMATIONS");// Giving name to window
    glClearColor(1.0, 1.0, 1.0, 1.0); //Clear the buffer values for color AND set these values
    /*can set initial color here also*/
    glMatrixMode(GL_PROJECTION);  //Uses something called "projection matrix" to represent
    glLoadIdentity(); //load the above matrix to fill with identity values
    glOrtho(-454.0, 454.0, -250.0, 250.0, -250.0, 250.0);
    gluPerspective(100, 100, 100, 100);
    glEnable(GL_DEPTH_TEST);
    glutDisplayFunc(display); //sets the display callback for the current window
    glutMainLoop(); //Enters event processing loop. Compulsory
   return 0;
}
